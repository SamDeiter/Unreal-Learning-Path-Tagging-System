// SCORM 1.2 API Wrapper
var SCORM = {
    api: null,
    initialized: false,

    // Find LMS API
    findAPI: function(win) {
        var tries = 0;
        while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
            tries++;
            if (tries > 7) return null;
            win = win.parent;
        }
        return win.API;
    },

    getAPI: function() {
        if (this.api == null) {
            this.api = this.findAPI(window);
            if ((this.api == null) && (window.opener != null)) {
                this.api = this.findAPI(window.opener);
            }
        }
        return this.api;
    },

    init: function() {
        var api = this.getAPI();
        if (api != null) {
            var result = api.LMSInitialize("");
            if (result == "true" || result == true) {
                this.initialized = true;
                // Set initial status
                api.LMSSetValue("cmi.core.lesson_status", "incomplete");
                return true;
            }
        }
        console.log("SCORM: Running in standalone mode (no LMS detected)");
        this.initialized = true; // Allow standalone testing
        return false;
    },

    finish: function() {
        if (this.initialized) {
            var api = this.getAPI();
            if (api != null) {
                api.LMSCommit("");
                api.LMSFinish("");
            }
        }
    },

    setStepComplete: function(stepNum) {
        var api = this.getAPI();
        var completed = this.getCompletedSteps();
        if (!completed.includes(stepNum)) {
            completed.push(stepNum);
        }

        // Store in suspend_data
        if (api != null) {
            api.LMSSetValue("cmi.suspend_data", JSON.stringify({completed: completed}));
            api.LMSCommit("");

            // Update score based on completion
            var totalSteps = document.querySelectorAll('.step-link').length || 4;
            var score = Math.round((completed.length / totalSteps) * 100);
            api.LMSSetValue("cmi.core.score.raw", score.toString());

            // Set completed if all steps done
            if (completed.length >= totalSteps) {
                api.LMSSetValue("cmi.core.lesson_status", "completed");
            }
        }

        // Local storage fallback
        localStorage.setItem('scorm_completed', JSON.stringify(completed));

        this.updateProgress(completed.length);
    },

    getStepComplete: function(stepNum) {
        return this.getCompletedSteps().includes(stepNum);
    },

    getCompletedSteps: function() {
        var api = this.getAPI();
        var data = null;

        if (api != null) {
            var suspendData = api.LMSGetValue("cmi.suspend_data");
            if (suspendData) {
                try {
                    data = JSON.parse(suspendData);
                } catch(e) {}
            }
        }

        // Fallback to localStorage
        if (!data) {
            var local = localStorage.getItem('scorm_completed');
            if (local) {
                try {
                    return JSON.parse(local);
                } catch(e) {}
            }
        }

        return data ? (data.completed || []) : [];
    },

    updateProgress: function(completedCount) {
        var totalSteps = document.querySelectorAll('.step-link').length || 4;
        var percent = Math.round((completedCount / totalSteps) * 100);

        var progressText = document.getElementById('progress-text');
        var progressFill = document.getElementById('progress-fill');

        if (progressText) progressText.textContent = 'Progress: ' + percent + '%';
        if (progressFill) progressFill.style.width = percent + '%';
    }
};
